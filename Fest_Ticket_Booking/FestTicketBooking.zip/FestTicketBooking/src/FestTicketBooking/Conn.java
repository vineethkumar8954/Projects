package FestTicketBooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conn implements AutoCloseable { // Implement AutoCloseable
    public Connection c;
    public Statement s;

    public Conn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3309/festticketbooking", "root", "root"); // Fixed username
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() { // Override close for try-with-resources
        try {
            if (s != null) s.close();
            if (c != null) c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
