package FestTicketBooking;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.print.*;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.imageio.ImageIO;
import javax.swing.*;

public class EntryPass {

    private BufferedImage templateImage; // Template image
    private JFrame frame;
    private JPanel passPanel;
    private JLabel lblDetails;
    private JLabel lblDateTime; // For date and time display
    private LocalDateTime selectedDateTime; // Stores the selected date and time

    public void openEntryPassWindow() {
        frame = new JFrame("Entry Pass");
        frame.setSize(600, 800);
        frame.setLayout(null);

        JLabel lblPNR = new JLabel("Enter PNR:");
        lblPNR.setBounds(50, 50, 100, 25);
        frame.add(lblPNR);

        JTextField tfPNR = new JTextField();
        tfPNR.setBounds(150, 50, 200, 25);
        frame.add(tfPNR);

        JButton btnGeneratePass = new JButton("Generate Pass");
        btnGeneratePass.setBounds(150, 100, 150, 30);
        frame.add(btnGeneratePass);

        JButton btnPrintPass = new JButton("Print Pass");
        btnPrintPass.setBounds(350, 100, 150, 30);
        btnPrintPass.setEnabled(false); // Initially disabled
        frame.add(btnPrintPass);

        // Add Date and Time Buttons
        JButton btnSetDateTime = new JButton("Set Current Date & Time");
        btnSetDateTime.setBounds(50, 150, 200, 30);
        frame.add(btnSetDateTime);

        JButton btnClearDateTime = new JButton("Clear Date & Time");
        btnClearDateTime.setBounds(300, 150, 150, 30);
        frame.add(btnClearDateTime);

        // Panel to display the pass
        passPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (templateImage != null) {
                    g.drawImage(templateImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        passPanel.setBounds(50, 200, 1400, 600);
        passPanel.setLayout(null);
        frame.add(passPanel);

        lblDetails = new JLabel();
        lblDateTime = new JLabel(); // Label for date and time
        lblDateTime.setFont(new Font("ARIAL", Font.BOLD, 25));
        lblDateTime.setForeground(Color.WHITE);

        btnSetDateTime.addActionListener(e -> {
            selectedDateTime = LocalDateTime.now();
            String formattedDateTime = selectedDateTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm a"));
            lblDateTime.setText("Date & Time: " + formattedDateTime);
            lblDateTime.setBounds(980, 30, 400, 25);
            passPanel.add(lblDateTime);
            passPanel.revalidate();
            passPanel.repaint();
        });

        btnClearDateTime.addActionListener(e -> {
            selectedDateTime = null;
            lblDateTime.setText("");
            passPanel.remove(lblDateTime);
            passPanel.revalidate();
            passPanel.repaint();
        });

        btnGeneratePass.addActionListener(e -> {
            String pnr = tfPNR.getText();
            String details = fetchEntryPassDetails(pnr);
            if (details != null) {
                populatePass(details);
                btnPrintPass.setEnabled(true); // Enable print button
            } else {
                JOptionPane.showMessageDialog(frame, "PNR not found! Please enter a valid PNR.");
            }
        });

        btnPrintPass.addActionListener(e -> printPass());

        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public void loadTemplate(String templatePath) {
        try {
            templateImage = ImageIO.read(new File(templatePath));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Failed to load template image.");
        }
    }

    public String fetchEntryPassDetails(String pnr) {
        String query = "SELECT * FROM reservation WHERE PNR = ?";
        try (Connection conn = new Conn().c; PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, pnr);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                StringBuilder details = new StringBuilder();
                details.append("PNR: ").append(rs.getString("PNR")).append("\n");
                details.append("Name: ").append(rs.getString("name")).append("\n");
                details.append("Event Name: ").append(rs.getString("flightname")).append("\n");
                details.append("Event Code: ").append(rs.getString("flightcode")).append("\n");
                details.append("Place: ").append(rs.getString("src")).append("\n");
                return details.toString();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error fetching details: " + e.getMessage());
        }
        return null;
    }

    public void populatePass(String details) {
        passPanel.removeAll();
        lblDetails.setText("<html>" + details.replace("\n", "<br>") + "</html>");
        lblDetails.setFont(new Font("Times New Roman", Font.BOLD, 28));
        lblDetails.setForeground(Color.BLACK);
        lblDetails.setBounds(500, 50, 1400, 600);
        passPanel.add(lblDetails);

        if (selectedDateTime != null) {
            String formattedDateTime = selectedDateTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm a"));
            lblDateTime.setText("Date & Time: " + formattedDateTime);
            lblDateTime.setBounds(50, 10, 400, 300);
            passPanel.add(lblDateTime);
        }

        passPanel.revalidate();
        passPanel.repaint();
    }

    public void printPass() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable((g, pf, pageIndex) -> {
            if (pageIndex > 0) {
                return Printable.NO_SUCH_PAGE;
            }

            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());

            int imgWidth = templateImage.getWidth();
            int imgHeight = templateImage.getHeight();
            int printableWidth = (int) pf.getImageableWidth();
            int printableHeight = (int) pf.getImageableHeight();

            float widthScale = (float) printableWidth / imgWidth;
            float heightScale = (float) printableHeight / imgHeight;
            float scale = Math.min(widthScale, heightScale);

            int scaledWidth = (int) (imgWidth * scale);
            int scaledHeight = (int) (imgHeight * scale);

            int x = (printableWidth - scaledWidth) / 2;
            int y = (printableHeight - scaledHeight) / 2;

            g2d.drawImage(templateImage, x, y, scaledWidth, scaledHeight, null);

            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Times New Roman", Font.BOLD, 12));

            // Strip HTML tags and handle <br> as newlines
            String details = lblDetails.getText()
                    .replaceAll("<br>", "\n") // Convert <br> to newlines
                    .replaceAll("<[^>]+>", ""); // Remove other HTML tags
            String[] lines = details.split("\n");
            int lineHeight = g2d.getFontMetrics().getHeight();
            int startX = x + 210; // Adjust alignment for details
            int startY = y + 90;

            for (String line : lines) {
                g2d.drawString(line, startX, startY);
                startY += lineHeight;
            }

            // Align date and time to the right-middle
            if (selectedDateTime != null) {
                String formattedDateTime = selectedDateTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm a"));

                int dateTimeWidth = g2d.getFontMetrics().stringWidth("Date & Time: " + formattedDateTime);
                int dateTimeX = printableWidth - dateTimeWidth - 5; // 30px padding from the right edge
                int dateTimeY = (printableHeight / 2) - 85 + (g2d.getFontMetrics().getHeight() / 2); // Vertically centered

                // Set custom color and font for date and time
                g2d.setColor(Color.WHITE); // Change to your desired color
                g2d.setFont(new Font("Bookmam", Font.ITALIC, 11)); // Set desired font and size

                g2d.drawString("Date & Time: " + formattedDateTime, dateTimeX, dateTimeY);

                // Reset color and font if needed to avoid affecting other text
                g2d.setColor(Color.BLACK); // Reset to default color
                g2d.setFont(new Font("Times New Roman", Font.BOLD, 12)); // Reset to default font
            }

            return Printable.PAGE_EXISTS;
        });

        if (job.printDialog()) {
            try {
                job.print();
            } catch (PrinterException e) {
                JOptionPane.showMessageDialog(frame, "Error occurred while printing: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        EntryPass entryPass = new EntryPass();
        entryPass.loadTemplate("C:\\Users\\WIN10\\Desktop\\FestTicketBooking\\src\\template.jpg");
        entryPass.openEntryPassWindow();
    }
}


