package FestTicketBooking;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignUp extends JFrame implements ActionListener {

    JTextField tfUsername, tfName, tfPassword, tfPhone;
    JButton register, back;

    public SignUp() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;

        JLabel lblUsername = new JLabel("Username");
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(lblUsername, gbc);

        tfUsername = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipadx = 200;
        gbc.ipady = 20;
        add(tfUsername, gbc);

        JLabel lblName = new JLabel("Name");
        lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(lblName, gbc);

        tfName = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.ipadx = 200;
        gbc.ipady = 20;
        add(tfName, gbc);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(lblPassword, gbc);

        tfPassword = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.ipadx = 200;
        gbc.ipady = 20;
        add(tfPassword, gbc);

        JLabel lblPhone = new JLabel("Phone");
        lblPhone.setFont(new Font("Tahoma", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(lblPhone, gbc);

        tfPhone = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.ipadx = 200;
        gbc.ipady = 20;
        add(tfPhone, gbc);

        register = new JButton("Register");
        register.setBackground(Color.BLACK);
        register.setForeground(Color.WHITE);
        register.addActionListener(this);
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(register, gbc);

        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        add(back, gbc);

        setExtendedState(JFrame.MAXIMIZED_BOTH); // Make the frame full screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == register) {
            String username = tfUsername.getText();
            String name = tfName.getText();
            String password = tfPassword.getText();
            String phone = tfPhone.getText();

            if (username.isEmpty() || name.isEmpty() || password.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required!");
            } else {
                try {
                    Conn conn = new Conn();
                    String query = "insert into users values('" + username + "', '" + name + "', '" + password + "', '" + phone + "')";
                    conn.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Account Created Successfully");
                    setVisible(false);
                    new Home();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (ae.getSource() == back) {
            setVisible(false);
            new WelcomePage();
        }
    }

    public static void main(String[] args) {
        new SignUp();
    }
}
