package FestTicketBooking;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Home extends JFrame implements ActionListener {

    public Home() {
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("FestTicketBooking/icons/pic12.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1600, 910);
        add(image);

        JLabel heading = new JLabel("FESTIFY WELCOMES YOU");
        heading.setBounds(390, 200, 2000, 40);
        heading.setForeground(Color.BLACK);
        heading.setFont(new Font("Roman", Font.BOLD, 50));
        image.add(heading);

        JMenuBar menubar = new JMenuBar();
        setJMenuBar(menubar);

        JMenu details = new JMenu("Details");
        menubar.add(details);

        JMenuItem festDetails = new JMenuItem("Fest Details");
        festDetails.addActionListener(this);
        details.add(festDetails);

        JMenuItem customerDetails = new JMenuItem("Add Customer Details");
        customerDetails.addActionListener(this);
        details.add(customerDetails);

        JMenuItem bookTicket = new JMenuItem("Book Ticket");
        bookTicket.addActionListener(this);
        details.add(bookTicket);

        JMenuItem location = new JMenuItem("Location");
        location.addActionListener(this);
        details.add(location);

        JMenuItem ticketCancellation = new JMenuItem("Cancel Ticket");
        ticketCancellation.addActionListener(this);
        details.add(ticketCancellation);

        JMenu ticket = new JMenu("Ticket");
        menubar.add(ticket);

        JMenuItem boardingPass = new JMenuItem("Entry Pass");
        boardingPass.addActionListener(this);
        ticket.add(boardingPass);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String text = ae.getActionCommand();

        if (text.equals("Add Customer Details")) {
            new AddCustomer();
        } else if (text.equals("Fest Details")) {
            new FestInfo();
        } else if (text.equals("Book Ticket")) {
            new BookTicket();
        } else if (text.equals("Location")) {
            new Location();
        } else if (text.equals("Cancel Ticket")) {
            new Cancel();
        } else if (text.equals("Entry Pass")) {
            EntryPass entryPass = new EntryPass();
            entryPass.loadTemplate("C:\\Users\\WIN10\\Desktop\\FestTicketBooking\\src\\template.jpg");
            entryPass.openEntryPassWindow();
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}