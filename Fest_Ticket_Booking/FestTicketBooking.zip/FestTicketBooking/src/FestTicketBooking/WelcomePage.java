package FestTicketBooking;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class WelcomePage extends JFrame implements ActionListener {

    JButton login, signup;

    public WelcomePage() {
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Make the frame full screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set background image
        ImageIcon backgroundImg = new ImageIcon(ClassLoader.getSystemResource("FestTicketBooking/icons/pic12.jpg"));
        Image img = backgroundImg.getImage();
        Image tempImg = img.getScaledInstance(1920, 1080, Image.SCALE_SMOOTH);
        backgroundImg = new ImageIcon(tempImg);
        JLabel background = new JLabel(backgroundImg);
        background.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); // Padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Add heading
        JLabel heading = new JLabel("WELCOME TO FESTIFY");
        heading.setForeground(Color.BLACK);
        heading.setFont(new Font("Tahoma", Font.BOLD, 50));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(100, 20, 50, 20); // Top padding
        background.add(heading, gbc);

        // Add login button
        login = new JButton("Login");
        login.setPreferredSize(new Dimension(300, 50)); // Set button size
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(20, 20, 20, 20); // Reset padding
        background.add(login, gbc);

        // Add signup button
        signup = new JButton("Sign Up");
        signup.setPreferredSize(new Dimension(300, 50)); // Set button size
        signup.setBackground(Color.BLACK);
        signup.setForeground(Color.WHITE);
        signup.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 1;
        background.add(signup, gbc);

        // Add background to frame
        add(background);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == login) {
            setVisible(false);
            new SignIn();
        } else if (ae.getSource() == signup) {
            setVisible(false);
            new SignUp();
        }
    }

    public static void main(String[] args) {
        new WelcomePage();
    }
}
